"""CloudConnection — linked Azure (and later AWS) subscriptions."""

from datetime import datetime, timezone
from sqlalchemy import String, DateTime, Boolean, Integer, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class CloudConnection(Base):
    __tablename__ = "cloud_connections"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False, index=True)
    provider: Mapped[str] = mapped_column(String(20), nullable=False, default="azure")  # azure, aws (Phase 2)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)

    # Azure-specific
    subscription_id: Mapped[str] = mapped_column(String(100), nullable=True, index=True)
    tenant_id: Mapped[str] = mapped_column(String(100), nullable=True)

    # Auth — uses service principal (no stored secrets; managed identity preferred)
    auth_method: Mapped[str] = mapped_column(String(50), default="service_principal")  # service_principal, managed_identity

    # Status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_ingestion_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)
    ingestion_status: Mapped[str] = mapped_column(String(50), default="pending")  # pending, running, completed, failed
    ingestion_error: Mapped[str] = mapped_column(String(1000), nullable=True)

    # Metadata
    metadata_json: Mapped[dict] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )

    organization = relationship("Organization", back_populates="cloud_connections")
