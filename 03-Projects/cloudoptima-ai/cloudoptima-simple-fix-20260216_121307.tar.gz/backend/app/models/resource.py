"""Resource — tracked cloud resources with utilization metadata."""

from datetime import datetime, timezone
from sqlalchemy import String, DateTime, Float, Integer, ForeignKey, JSON, Boolean
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Resource(Base):
    __tablename__ = "resources"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False, index=True)
    cloud_connection_id: Mapped[int] = mapped_column(ForeignKey("cloud_connections.id"), nullable=False, index=True)

    # FOCUS-aligned identity
    resource_id: Mapped[str] = mapped_column(String(500), nullable=False, index=True)  # Full ARM resource ID
    resource_name: Mapped[str] = mapped_column(String(255), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(255), nullable=False)  # e.g., Microsoft.Compute/virtualMachines
    resource_group: Mapped[str] = mapped_column(String(255), nullable=True)
    region: Mapped[str] = mapped_column(String(100), nullable=True)
    provider: Mapped[str] = mapped_column(String(50), default="Azure")

    # Sizing / SKU
    sku: Mapped[str] = mapped_column(String(100), nullable=True)  # e.g., Standard_D4s_v3
    sku_family: Mapped[str] = mapped_column(String(100), nullable=True)  # e.g., Dv3

    # Utilization (updated by monitor service)
    avg_cpu_percent: Mapped[float] = mapped_column(Float, nullable=True)
    avg_memory_percent: Mapped[float] = mapped_column(Float, nullable=True)
    avg_gpu_percent: Mapped[float] = mapped_column(Float, nullable=True)
    is_gpu_enabled: Mapped[bool] = mapped_column(Boolean, default=False)

    # Cost summary (rolling 30-day)
    cost_30d: Mapped[float] = mapped_column(Float, nullable=True)
    cost_trend: Mapped[str] = mapped_column(String(20), nullable=True)  # increasing, decreasing, stable

    # Tags & metadata
    tags: Mapped[dict] = mapped_column(JSON, nullable=True)
    is_idle: Mapped[bool] = mapped_column(Boolean, default=False)

    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
