"""AIWorkload — tracks AI/ML service usage and costs (the differentiator).

This is CloudOptima AI's unique wedge: purpose-built tracking for
Azure OpenAI, Cognitive Services, ML Studio, and GPU-enabled VMs.
"""

from datetime import datetime, timezone, date
from sqlalchemy import String, DateTime, Date, Float, Integer, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class AIWorkload(Base):
    __tablename__ = "ai_workloads"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False, index=True)
    cloud_connection_id: Mapped[int] = mapped_column(ForeignKey("cloud_connections.id"), nullable=False, index=True)

    # AI service identity
    service_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    # Types: azure_openai, cognitive_services, azure_ml, gpu_vm
    resource_id: Mapped[str] = mapped_column(String(500), nullable=True, index=True)
    resource_name: Mapped[str] = mapped_column(String(255), nullable=True)
    deployment_name: Mapped[str] = mapped_column(String(255), nullable=True)  # Azure OpenAI deployment
    model_name: Mapped[str] = mapped_column(String(100), nullable=True)  # gpt-4, gpt-35-turbo, etc.

    # Period
    period_start: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    period_end: Mapped[date] = mapped_column(Date, nullable=False)

    # Cost
    total_cost: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    cost_per_day_avg: Mapped[float] = mapped_column(Float, nullable=True)

    # Token usage (Azure OpenAI specific)
    prompt_tokens: Mapped[int] = mapped_column(Integer, nullable=True)
    completion_tokens: Mapped[int] = mapped_column(Integer, nullable=True)
    total_tokens: Mapped[int] = mapped_column(Integer, nullable=True)
    cost_per_1k_tokens: Mapped[float] = mapped_column(Float, nullable=True)

    # Inference metrics
    total_requests: Mapped[int] = mapped_column(Integer, nullable=True)
    cost_per_request: Mapped[float] = mapped_column(Float, nullable=True)

    # GPU metrics (for GPU VMs)
    gpu_sku: Mapped[str] = mapped_column(String(100), nullable=True)  # NC6s_v3, ND40rs_v2, etc.
    avg_gpu_utilization: Mapped[float] = mapped_column(Float, nullable=True)  # 0-100%
    gpu_hours: Mapped[float] = mapped_column(Float, nullable=True)
    cost_per_gpu_hour: Mapped[float] = mapped_column(Float, nullable=True)

    # Metadata
    metadata_json: Mapped[dict] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
