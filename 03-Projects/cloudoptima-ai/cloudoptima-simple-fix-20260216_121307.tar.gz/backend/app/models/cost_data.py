"""CostData — FOCUS 1.3-native cost data (TimescaleDB hypertable).

Uses FOCUS (FinOps Open Cost and Usage Specification) v1.3 column naming
as the canonical schema. This eliminates custom normalization and ensures
interoperability with the FOCUS ecosystem.

Reference: https://focus.finops.org/
"""

from datetime import datetime, timezone, date
from sqlalchemy import (
    String, DateTime, Date, Float, Integer, ForeignKey, Index, event, text
)
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class CostData(Base):
    """Cost line items stored using FOCUS 1.3 column names.

    This table is converted to a TimescaleDB hypertable on BillingPeriodStart
    for efficient time-series queries (cost trends, aggregations, anomalies).
    """
    __tablename__ = "cost_data"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False, index=True)
    cloud_connection_id: Mapped[int] = mapped_column(ForeignKey("cloud_connections.id"), nullable=False, index=True)

    # ── FOCUS 1.3 Core Columns ──────────────────────────────────────

    # Time
    BillingPeriodStart: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    BillingPeriodEnd: Mapped[date] = mapped_column(Date, nullable=False)
    ChargePeriodStart: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    ChargePeriodEnd: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    # Identity
    BillingAccountId: Mapped[str] = mapped_column(String(255), nullable=True)  # Azure subscription ID
    BillingAccountName: Mapped[str] = mapped_column(String(255), nullable=True)
    SubAccountId: Mapped[str] = mapped_column(String(255), nullable=True)  # Resource group
    SubAccountName: Mapped[str] = mapped_column(String(255), nullable=True)

    # Resource
    ResourceId: Mapped[str] = mapped_column(String(500), nullable=True, index=True)
    ResourceName: Mapped[str] = mapped_column(String(255), nullable=True)
    ResourceType: Mapped[str] = mapped_column(String(255), nullable=True)  # e.g., Microsoft.Compute/virtualMachines
    Region: Mapped[str] = mapped_column(String(100), nullable=True, index=True)

    # Service
    ServiceName: Mapped[str] = mapped_column(String(255), nullable=True, index=True)
    ServiceCategory: Mapped[str] = mapped_column(String(255), nullable=True)  # AI + Machine Learning, Compute, etc.
    PublisherName: Mapped[str] = mapped_column(String(255), nullable=True)

    # Pricing
    PricingCategory: Mapped[str] = mapped_column(String(100), nullable=True)  # On-Demand, Commitment, Spot
    PricingUnit: Mapped[str] = mapped_column(String(100), nullable=True)
    PricingQuantity: Mapped[float] = mapped_column(Float, nullable=True)
    SkuId: Mapped[str] = mapped_column(String(255), nullable=True)
    SkuPriceId: Mapped[str] = mapped_column(String(255), nullable=True)

    # Cost
    BilledCost: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    EffectiveCost: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    ListCost: Mapped[float] = mapped_column(Float, nullable=True)
    BillingCurrency: Mapped[str] = mapped_column(String(10), default="USD")

    # Usage
    UsageQuantity: Mapped[float] = mapped_column(Float, nullable=True)
    UsageUnit: Mapped[str] = mapped_column(String(100), nullable=True)
    ConsumedQuantity: Mapped[float] = mapped_column(Float, nullable=True)
    ConsumedUnit: Mapped[str] = mapped_column(String(100), nullable=True)

    # Charge
    ChargeCategory: Mapped[str] = mapped_column(String(100), nullable=True)  # Usage, Purchase, Tax, Credit
    ChargeFrequency: Mapped[str] = mapped_column(String(50), nullable=True)  # One-Time, Recurring, Usage-Based
    ChargeDescription: Mapped[str] = mapped_column(String(500), nullable=True)

    # Commitment
    CommitmentDiscountId: Mapped[str] = mapped_column(String(255), nullable=True)
    CommitmentDiscountName: Mapped[str] = mapped_column(String(255), nullable=True)
    CommitmentDiscountCategory: Mapped[str] = mapped_column(String(100), nullable=True)

    # Tags (stored as semicolon-separated key:value pairs for queryability)
    Tags: Mapped[str] = mapped_column(String(2000), nullable=True)

    # Provider
    Provider: Mapped[str] = mapped_column(String(50), nullable=False, default="Azure")

    # ── Metadata ────────────────────────────────────────────────────
    ingested_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )

    __table_args__ = (
        Index("ix_cost_data_org_billing", "organization_id", "BillingPeriodStart"),
        Index("ix_cost_data_service_period", "ServiceName", "BillingPeriodStart"),
        Index("ix_cost_data_category_period", "ServiceCategory", "BillingPeriodStart"),
    )


# ── TimescaleDB Hypertable Creation ─────────────────────────────────
# After table creation, convert to hypertable for time-series performance.
# This runs once when tables are first created.

@event.listens_for(CostData.__table__, "after_create")
def create_hypertable(target, connection, **kwargs):
    """Convert cost_data to a TimescaleDB hypertable partitioned by BillingPeriodStart."""
    try:
        connection.execute(text(
            "SELECT create_hypertable('cost_data', 'BillingPeriodStart', "
            "if_not_exists => TRUE, migrate_data => TRUE);"
        ))
    except Exception:
        pass  # Hypertable may already exist
