"""Recommendation routes — MVP Feature #2 (basic recs)."""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.models.recommendation import Recommendation
from app.schemas import RecommendationResponse, RecommendationUpdate, RecommendationSummary

router = APIRouter()


@router.get("/", response_model=list[RecommendationResponse])
async def list_recommendations(
    status: str = Query(default="open", pattern="^(open|accepted|dismissed|implemented|all)$"),
    category: str = Query(default=None),
    impact: str = Query(default=None, pattern="^(high|medium|low)$"),
    limit: int = Query(default=50, le=200),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List recommendations for the organization."""
    query = (
        select(Recommendation)
        .where(Recommendation.organization_id == current_user.organization_id)
        .order_by(Recommendation.estimated_monthly_savings.desc())
        .limit(limit)
    )
    if status != "all":
        query = query.where(Recommendation.status == status)
    if category:
        query = query.where(Recommendation.category == category)
    if impact:
        query = query.where(Recommendation.impact == impact)

    result = await db.execute(query)
    return result.scalars().all()


@router.get("/summary", response_model=RecommendationSummary)
async def get_recommendation_summary(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get summary of all open recommendations."""
    # Total open + savings
    totals = await db.execute(
        select(
            func.count(Recommendation.id).label("total"),
            func.coalesce(func.sum(Recommendation.estimated_monthly_savings), 0).label("monthly"),
            func.coalesce(func.sum(Recommendation.estimated_annual_savings), 0).label("annual"),
        ).where(
            Recommendation.organization_id == current_user.organization_id,
            Recommendation.status == "open",
        )
    )
    t = totals.one()

    # By category
    cat_result = await db.execute(
        select(Recommendation.category, func.count(Recommendation.id))
        .where(
            Recommendation.organization_id == current_user.organization_id,
            Recommendation.status == "open",
        )
        .group_by(Recommendation.category)
    )
    by_category = {r[0]: r[1] for r in cat_result.all()}

    # By impact
    impact_result = await db.execute(
        select(Recommendation.impact, func.count(Recommendation.id))
        .where(
            Recommendation.organization_id == current_user.organization_id,
            Recommendation.status == "open",
        )
        .group_by(Recommendation.impact)
    )
    by_impact = {r[0]: r[1] for r in impact_result.all()}

    return RecommendationSummary(
        total_open=t.total,
        total_monthly_savings=round(t.monthly, 2),
        total_annual_savings=round(t.annual, 2),
        by_category=by_category,
        by_impact=by_impact,
    )


@router.patch("/{recommendation_id}", response_model=RecommendationResponse)
async def update_recommendation(
    recommendation_id: int,
    data: RecommendationUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update recommendation status (accept, dismiss, implement)."""
    result = await db.execute(
        select(Recommendation).where(
            Recommendation.id == recommendation_id,
            Recommendation.organization_id == current_user.organization_id,
        )
    )
    rec = result.scalar_one_or_none()
    if not rec:
        raise HTTPException(status_code=404, detail="Recommendation not found")

    rec.status = data.status
    if data.dismissed_reason:
        rec.dismissed_reason = data.dismissed_reason
    if data.status == "implemented":
        from datetime import datetime, timezone
        rec.implemented_at = datetime.now(timezone.utc)

    return rec
