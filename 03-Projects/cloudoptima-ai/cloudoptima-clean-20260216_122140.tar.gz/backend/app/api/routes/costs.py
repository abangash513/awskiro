"""Cost data routes — Azure cost visibility (MVP Feature #1)."""

from datetime import date, timedelta

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.models.cost_data import CostData
from app.schemas import CostSummary, CostTrend, CostByDimension

router = APIRouter()


@router.get("/summary", response_model=CostSummary)
async def get_cost_summary(
    start_date: date = Query(default=None),
    end_date: date = Query(default=None),
    connection_id: int = Query(default=None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get aggregated cost summary for a time period."""
    if not end_date:
        end_date = date.today()
    if not start_date:
        start_date = end_date - timedelta(days=30)

    # Current period costs
    query = (
        select(
            func.sum(CostData.BilledCost).label("total_billed"),
            func.sum(CostData.EffectiveCost).label("total_effective"),
        )
        .where(
            CostData.organization_id == current_user.organization_id,
            CostData.BillingPeriodStart >= start_date,
            CostData.BillingPeriodStart <= end_date,
        )
    )
    if connection_id:
        query = query.where(CostData.cloud_connection_id == connection_id)

    result = await db.execute(query)
    row = result.one()

    # Prior period for comparison
    period_days = (end_date - start_date).days
    prior_start = start_date - timedelta(days=period_days)
    prior_end = start_date - timedelta(days=1)

    prior_query = (
        select(func.sum(CostData.BilledCost).label("prior_total"))
        .where(
            CostData.organization_id == current_user.organization_id,
            CostData.BillingPeriodStart >= prior_start,
            CostData.BillingPeriodStart <= prior_end,
        )
    )
    if connection_id:
        prior_query = prior_query.where(CostData.cloud_connection_id == connection_id)

    prior_result = await db.execute(prior_query)
    prior_total = prior_result.scalar() or 0

    current_total = row.total_billed or 0
    change_pct = None
    if prior_total > 0:
        change_pct = round(((current_total - prior_total) / prior_total) * 100, 1)

    # Top services
    svc_query = (
        select(
            CostData.ServiceName,
            func.sum(CostData.BilledCost).label("cost"),
        )
        .where(
            CostData.organization_id == current_user.organization_id,
            CostData.BillingPeriodStart >= start_date,
            CostData.BillingPeriodStart <= end_date,
        )
        .group_by(CostData.ServiceName)
        .order_by(func.sum(CostData.BilledCost).desc())
        .limit(10)
    )
    svc_result = await db.execute(svc_query)
    top_services = [
        {"service": r.ServiceName or "Unknown", "cost": round(r.cost, 2)}
        for r in svc_result.all()
    ]

    # Top resource groups
    rg_query = (
        select(
            CostData.SubAccountName,
            func.sum(CostData.BilledCost).label("cost"),
        )
        .where(
            CostData.organization_id == current_user.organization_id,
            CostData.BillingPeriodStart >= start_date,
            CostData.BillingPeriodStart <= end_date,
        )
        .group_by(CostData.SubAccountName)
        .order_by(func.sum(CostData.BilledCost).desc())
        .limit(10)
    )
    rg_result = await db.execute(rg_query)
    top_rgs = [
        {"resource_group": r.SubAccountName or "Unknown", "cost": round(r.cost, 2)}
        for r in rg_result.all()
    ]

    return CostSummary(
        total_billed_cost=round(current_total, 2),
        total_effective_cost=round(row.total_effective or 0, 2),
        period_start=start_date,
        period_end=end_date,
        cost_change_percent=change_pct,
        top_services=top_services,
        top_resource_groups=top_rgs,
    )


@router.get("/trend", response_model=list[CostTrend])
async def get_cost_trend(
    start_date: date = Query(default=None),
    end_date: date = Query(default=None),
    group_by: str = Query(default=None, pattern="^(service|resource_group)$"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get daily cost trend for charting."""
    if not end_date:
        end_date = date.today()
    if not start_date:
        start_date = end_date - timedelta(days=30)

    query = (
        select(
            CostData.BillingPeriodStart.label("date"),
            func.sum(CostData.BilledCost).label("billed_cost"),
            func.sum(CostData.EffectiveCost).label("effective_cost"),
        )
        .where(
            CostData.organization_id == current_user.organization_id,
            CostData.BillingPeriodStart >= start_date,
            CostData.BillingPeriodStart <= end_date,
        )
        .group_by(CostData.BillingPeriodStart)
        .order_by(CostData.BillingPeriodStart)
    )
    result = await db.execute(query)

    return [
        CostTrend(
            date=r.date,
            billed_cost=round(r.billed_cost, 2),
            effective_cost=round(r.effective_cost, 2),
        )
        for r in result.all()
    ]


@router.get("/by-service", response_model=list[CostByDimension])
async def get_cost_by_service(
    start_date: date = Query(default=None),
    end_date: date = Query(default=None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get cost breakdown by Azure service."""
    if not end_date:
        end_date = date.today()
    if not start_date:
        start_date = end_date - timedelta(days=30)

    query = (
        select(
            CostData.ServiceName,
            func.sum(CostData.BilledCost).label("billed"),
            func.sum(CostData.EffectiveCost).label("effective"),
        )
        .where(
            CostData.organization_id == current_user.organization_id,
            CostData.BillingPeriodStart >= start_date,
            CostData.BillingPeriodStart <= end_date,
        )
        .group_by(CostData.ServiceName)
        .order_by(func.sum(CostData.BilledCost).desc())
        .limit(20)
    )
    result = await db.execute(query)
    rows = result.all()

    total = sum(r.billed or 0 for r in rows)
    return [
        CostByDimension(
            dimension="service",
            value=r.ServiceName or "Unknown",
            billed_cost=round(r.billed or 0, 2),
            effective_cost=round(r.effective or 0, 2),
            percent_of_total=round((r.billed or 0) / total * 100, 1) if total > 0 else 0,
        )
        for r in rows
    ]


@router.get("/by-resource-group", response_model=list[CostByDimension])
async def get_cost_by_resource_group(
    start_date: date = Query(default=None),
    end_date: date = Query(default=None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get cost breakdown by resource group (SubAccountName in FOCUS)."""
    if not end_date:
        end_date = date.today()
    if not start_date:
        start_date = end_date - timedelta(days=30)

    query = (
        select(
            CostData.SubAccountName,
            func.sum(CostData.BilledCost).label("billed"),
            func.sum(CostData.EffectiveCost).label("effective"),
        )
        .where(
            CostData.organization_id == current_user.organization_id,
            CostData.BillingPeriodStart >= start_date,
            CostData.BillingPeriodStart <= end_date,
        )
        .group_by(CostData.SubAccountName)
        .order_by(func.sum(CostData.BilledCost).desc())
        .limit(20)
    )
    result = await db.execute(query)
    rows = result.all()

    total = sum(r.billed or 0 for r in rows)
    return [
        CostByDimension(
            dimension="resource_group",
            value=r.SubAccountName or "Unknown",
            billed_cost=round(r.billed or 0, 2),
            effective_cost=round(r.effective or 0, 2),
            percent_of_total=round((r.billed or 0) / total * 100, 1) if total > 0 else 0,
        )
        for r in rows
    ]
