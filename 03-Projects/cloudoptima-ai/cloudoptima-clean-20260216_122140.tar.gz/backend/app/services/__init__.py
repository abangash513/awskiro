"""Business logic services — Azure cost ingestion, recommendation engine."""
