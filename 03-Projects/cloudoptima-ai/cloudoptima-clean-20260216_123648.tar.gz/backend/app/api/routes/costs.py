"""Cost data routes — Simplified stub version."""

from datetime import date, timedelta
from typing import List

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.cost import CostRecord, CostSummary

router = APIRouter()


@router.get("/summary")
async def get_cost_summary(
    start_date: date = Query(default=None),
    end_date: date = Query(default=None),
    db: AsyncSession = Depends(get_db),
):
    """Get aggregated cost summary for a time period."""
    if not end_date:
        end_date = date.today()
    if not start_date:
        start_date = end_date - timedelta(days=30)

    # Get total costs
    query = select(func.sum(CostRecord.cost)).where(
        CostRecord.usage_date >= start_date,
        CostRecord.usage_date <= end_date,
    )
    result = await db.execute(query)
    total_cost = result.scalar() or 0

    # Get top services
    svc_query = (
        select(
            CostRecord.service_name,
            func.sum(CostRecord.cost).label("total"),
        )
        .where(
            CostRecord.usage_date >= start_date,
            CostRecord.usage_date <= end_date,
        )
        .group_by(CostRecord.service_name)
        .order_by(func.sum(CostRecord.cost).desc())
        .limit(10)
    )
    svc_result = await db.execute(svc_query)
    top_services = [
        {"service": r.service_name or "Unknown", "cost": round(r.total, 2)}
        for r in svc_result.all()
    ]

    return {
        "total_cost": round(total_cost, 2),
        "currency": "USD",
        "period_start": start_date.isoformat(),
        "period_end": end_date.isoformat(),
        "top_services": top_services,
    }


@router.get("/trend")
async def get_cost_trend(
    start_date: date = Query(default=None),
    end_date: date = Query(default=None),
    db: AsyncSession = Depends(get_db),
):
    """Get daily cost trend for charting."""
    if not end_date:
        end_date = date.today()
    if not start_date:
        start_date = end_date - timedelta(days=30)

    query = (
        select(
            CostRecord.usage_date,
            func.sum(CostRecord.cost).label("total_cost"),
        )
        .where(
            CostRecord.usage_date >= start_date,
            CostRecord.usage_date <= end_date,
        )
        .group_by(CostRecord.usage_date)
        .order_by(CostRecord.usage_date)
    )
    result = await db.execute(query)

    return [
        {
            "date": r.usage_date.isoformat(),
            "cost": round(r.total_cost, 2),
        }
        for r in result.all()
    ]


@router.get("/by-service")
async def get_cost_by_service(
    start_date: date = Query(default=None),
    end_date: date = Query(default=None),
    db: AsyncSession = Depends(get_db),
):
    """Get cost breakdown by service."""
    if not end_date:
        end_date = date.today()
    if not start_date:
        start_date = end_date - timedelta(days=30)

    query = (
        select(
            CostRecord.service_name,
            func.sum(CostRecord.cost).label("total"),
        )
        .where(
            CostRecord.usage_date >= start_date,
            CostRecord.usage_date <= end_date,
        )
        .group_by(CostRecord.service_name)
        .order_by(func.sum(CostRecord.cost).desc())
        .limit(20)
    )
    result = await db.execute(query)
    rows = result.all()

    total = sum(r.total or 0 for r in rows)
    return [
        {
            "service": r.service_name or "Unknown",
            "cost": round(r.total or 0, 2),
            "percent": round((r.total or 0) / total * 100, 1) if total > 0 else 0,
        }
        for r in rows
    ]


@router.get("/by-resource-group")
async def get_cost_by_resource_group(
    start_date: date = Query(default=None),
    end_date: date = Query(default=None),
    db: AsyncSession = Depends(get_db),
):
    """Get cost breakdown by resource group."""
    if not end_date:
        end_date = date.today()
    if not start_date:
        start_date = end_date - timedelta(days=30)

    query = (
        select(
            CostRecord.resource_group,
            func.sum(CostRecord.cost).label("total"),
        )
        .where(
            CostRecord.usage_date >= start_date,
            CostRecord.usage_date <= end_date,
        )
        .group_by(CostRecord.resource_group)
        .order_by(func.sum(CostRecord.cost).desc())
        .limit(20)
    )
    result = await db.execute(query)
    rows = result.all()

    total = sum(r.total or 0 for r in rows)
    return [
        {
            "resource_group": r.resource_group or "Unknown",
            "cost": round(r.total or 0, 2),
            "percent": round((r.total or 0) / total * 100, 1) if total > 0 else 0,
        }
        for r in rows
    ]
