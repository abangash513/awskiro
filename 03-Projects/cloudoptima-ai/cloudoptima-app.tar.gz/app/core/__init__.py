"""Core configuration and utilities."""
