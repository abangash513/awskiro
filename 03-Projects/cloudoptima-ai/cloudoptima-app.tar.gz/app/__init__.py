"""CloudOptima AI - Azure FinOps Tool"""

__version__ = "0.1.0"
__author__ = "CloudOptima Team"
