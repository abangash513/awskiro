import { query } from '../database/connection';
import { AuditLog } from '../types';

export class AuditService {
  static async logAccess(
    userId: string | undefined,
    action: string,
    resourceType: string,
    resourceId: string,
    details?: Record<string, unknown>,
    ipAddress?: string,
    userAgent?: string,
  ): Promise<void> {
    try {
      await query(
        `INSERT INTO audit_logs (user_id, action, resource_type, resource_id, details, ip_address, user_agent)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [userId || null, action, resourceType, resourceId, JSON.stringify(details || {}), ipAddress, userAgent],
      );
    } catch (error) {
      console.error('Audit logging error:', error);
      // Don't throw - audit logging should not break the application
    }
  }

  static async getAuditLogs(
    resourceType?: string,
    resourceId?: string,
    limit: number = 100,
    offset: number = 0,
  ): Promise<AuditLog[]> {
    try {
      let query_str = 'SELECT * FROM audit_logs WHERE 1=1';
      const params: unknown[] = [];
      let paramCount = 1;

      if (resourceType) {
        query_str += ` AND resource_type = $${paramCount++}`;
        params.push(resourceType);
      }

      if (resourceId) {
        query_str += ` AND resource_id = $${paramCount++}`;
        params.push(resourceId);
      }

      query_str += ` ORDER BY created_at DESC LIMIT $${paramCount++} OFFSET $${paramCount++}`;
      params.push(limit, offset);

      const result = await query(query_str, params);

      return result.rows.map((row: any) => ({
        id: row.id,
        userId: row.user_id,
        action: row.action,
        resourceType: row.resource_type,
        resourceId: row.resource_id,
        details: row.details,
        ipAddress: row.ip_address,
        userAgent: row.user_agent,
        createdAt: new Date(row.created_at),
      }));
    } catch (error) {
      console.error('Error retrieving audit logs:', error);
      return [];
    }
  }

  static async getUserAuditLogs(userId: string, limit: number = 100, offset: number = 0): Promise<AuditLog[]> {
    try {
      const result = await query(
        `SELECT * FROM audit_logs WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
        [userId, limit, offset],
      );

      return result.rows.map((row: any) => ({
        id: row.id,
        userId: row.user_id,
        action: row.action,
        resourceType: row.resource_type,
        resourceId: row.resource_id,
        details: row.details,
        ipAddress: row.ip_address,
        userAgent: row.user_agent,
        createdAt: new Date(row.created_at),
      }));
    } catch (error) {
      console.error('Error retrieving user audit logs:', error);
      return [];
    }
  }
}
